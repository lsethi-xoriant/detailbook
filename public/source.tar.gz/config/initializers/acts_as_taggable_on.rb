require 'models/acts_as_taggable_on-tag'
ActsAsTaggableOn.force_lowercase = true
