OpenGraphReader.configure do |config|
  config.synthesize_title      = true
  config.synthesize_url        = true
  config.synthesize_full_url   = true
  config.synthesize_image_url  = true
  config.guess_datetime_format = true
end
