Rails.application.config.markerb.renderer = Diaspora::Markdownify::Email
