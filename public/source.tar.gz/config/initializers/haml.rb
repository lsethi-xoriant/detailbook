Haml::Template.options[:format] = :html5
Haml::Template.options[:escape_html] = true
