require Rails.root.join('config', 'environment', 'development')

Diaspora::Application.configure do
end
