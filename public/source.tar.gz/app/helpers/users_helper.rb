module UsersHelper
  def owner_image_tag(size=nil)
    person_image_tag(current_user.person, size)
  end

  def owner_image_link
    person_image_link(current_user.person, :size => :thumb_small)
  end
end
